import random
def buildCap():
   return dictionary[random.randrange(0, len(dictionary))] + ' ' + dictionary[random.randrange(0, len(dictionary))] + ' ' + dictionary[random.randrange(0, len(dictionary))]


dictionary = ["love", "near", "ness", "ring", "wolf", "fish", "five", "king", "else", "tree", "over", "time", "able", "have", "sing", "star", "city", "soul", "rich", "duck", "foot", "film", "lion", "anna", "meme", "live", "safe", "pain", "rain", "sion", "iron", "once", "ball", "with", "fire", "wood", "care", "cake", "back", "lady", "away", "work", "self", "mole", "moon", "golf", "ally", "nine"]
